import{a as t}from"../chunks/entry.72ocKdoW.js";export{t as start};
